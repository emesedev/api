using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DNMX_FA_API.Data;
using DNMX_FA_API.Models;

namespace DNMX_FA_API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class GasConsumptionController : ControllerBase
    {
        private readonly AppDbContext _context;

        public GasConsumptionController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<GasConsumption>>> Get()
        {
            return await _context.Gas_consumption.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<GasConsumption>> Get(int id)
        {
            var item = await _context.Gas_consumption.FindAsync(id);
            if (item == null)
                return NotFound();
            return item;
        }

        [HttpPost]
        public async Task<ActionResult<GasConsumption>> Post(GasConsumption item)
        {
            _context.Gas_consumption.Add(item);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(Get), new { id = item.id_user }, item);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, GasConsumption item)
        {
            if (id != item.id_user)
                return BadRequest();

            _context.Entry(item).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Gas_consumption.Any(e => e.id_user == id))
                    return NotFound();
                else
                    throw;
            }
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var item = await _context.Gas_consumption.FindAsync(id);
            if (item == null)
                return NotFound();

            _context.Gas_consumption.Remove(item);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}