using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DNMX_FA_API.Data;
using DNMX_FA_API.Models;

namespace DNMX_FA_API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AreasController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AreasController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Areas>>> Get()
        {
            return await _context.Areas.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Areas>> Get(int id)
        {
            var item = await _context.Areas.FindAsync(id);
            if (item == null)
                return NotFound();
            return item;
        }

        [HttpPost]
        public async Task<ActionResult<Areas>> Post(Areas item)
        {
            _context.Areas.Add(item);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(Get), new { id = item.id_user }, item);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, Areas item)
        {
            if (id != item.id_user)
                return BadRequest();

            _context.Entry(item).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Areas.Any(e => e.id_user == id))
                    return NotFound();
                else
                    throw;
            }
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var item = await _context.Areas.FindAsync(id);
            if (item == null)
                return NotFound();

            _context.Areas.Remove(item);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}