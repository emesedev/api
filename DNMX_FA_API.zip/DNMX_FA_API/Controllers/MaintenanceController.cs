using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DNMX_FA_API.Data;
using DNMX_FA_API.Models;

namespace DNMX_FA_API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MaintenanceController : ControllerBase
    {
        private readonly AppDbContext _context;

        public MaintenanceController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Maintenance>>> Get()
        {
            return await _context.Maintenance.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Maintenance>> Get(int id)
        {
            var item = await _context.Maintenance.FindAsync(id);
            if (item == null)
                return NotFound();
            return item;
        }

        [HttpPost]
        public async Task<ActionResult<Maintenance>> Post(Maintenance item)
        {
            _context.Maintenance.Add(item);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(Get), new { id = item.id_user }, item);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, Maintenance item)
        {
            if (id != item.id_user)
                return BadRequest();

            _context.Entry(item).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Maintenance.Any(e => e.id_user == id))
                    return NotFound();
                else
                    throw;
            }
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var item = await _context.Maintenance.FindAsync(id);
            if (item == null)
                return NotFound();

            _context.Maintenance.Remove(item);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}