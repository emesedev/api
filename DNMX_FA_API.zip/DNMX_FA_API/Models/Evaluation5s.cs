using System;

namespace DNMX_FA_API.Models
{
    public class Evaluation5s
    {
        public int id_evaluation_5s { get; set; }
        public int columns { get; set; }
        public int row { get; set; }
        public string name { get; set; }
        public int id_area_fa { get; set; }
        public string area { get; set; }
        public int responsible { get; set; }
        public int approver { get; set; }
        public int status { get; set; }
    }
}