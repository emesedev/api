using System;

namespace DNMX_FA_API.Models
{
    public class CategoryEquipment
    {
        public int id_category_equipment { get; set; }
        public string category { get; set; }
        public int id_area_fa { get; set; }
    }
}