using System;

namespace DNMX_FA_API.Models
{
    public class MaintenanceResult
    {
        public int id_maintenance_result { get; set; }
        public int id_work_order { get; set; }
        public string result { get; set; }
        public string value1 { get; set; }
        public string value2 { get; set; }
        public string value3 { get; set; }
        public string comment { get; set; }
        public DateTime created_date { get; set; }
        public TimeSpan created_time { get; set; }
        public int status { get; set; }
    }
}