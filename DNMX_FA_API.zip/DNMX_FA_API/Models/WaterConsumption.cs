using System;

namespace DNMX_FA_API.Models
{
    public class WaterConsumption
    {
        public int id_water_consumptionint { get; set; }
        public float ciudad { get; set; }
        public float booster_potable { get; set; }
        public float tina_lavado { get; set; }
        public float entrada_suavizador { get; set; }
        public float salida_suavizador { get; set; }
        public float booster_suavizada { get; set; }
        public float ecopond { get; set; }
        public float osmosis { get; set; }
        public float surface { get; set; }
        public float cocina { get; set; }
        public float guarderia { get; set; }
        public float riego { get; set; }
        public float lav_1 { get; set; }
        public float lav_2 { get; set; }
        public float lav_3 { get; set; }
        public float lav_4 { get; set; }
        public float lav_5 { get; set; }
        public float lav_6 { get; set; }
        public float lav_7 { get; set; }
        public float lav_8 { get; set; }
        public float lav_9 { get; set; }
        public float torre_1 { get; set; }
        public float torre_2 { get; set; }
        public float torre_3 { get; set; }
    }
}