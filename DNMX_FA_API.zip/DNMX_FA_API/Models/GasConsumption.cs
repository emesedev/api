using System;

namespace DNMX_FA_API.Models
{
    public class GasConsumption
    {
        public int id_gas_consumption { get; set; }
        public DateTime date { get; set; }
        public float ciudad { get; set; }
        public float surface { get; set; }
        public float radiador { get; set; }
        public float evaporador { get; set; }
        public float brazing { get; set; }
        public float gic { get; set; }
        public float gic2 { get; set; }
        public float cocina { get; set; }
        public float guarderia { get; set; }
    }
}