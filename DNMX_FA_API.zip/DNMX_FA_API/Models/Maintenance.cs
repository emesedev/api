using System;

namespace DNMX_FA_API.Models
{
    public class Maintenance
    {
        public int id_maintenance { get; set; }
        public string name { get; set; }
        public int columns { get; set; }
        public int row { get; set; }
        public int frequency { get; set; }
        public int id_area_fa { get; set; }
        public int created_by { get; set; }
        public DateTime created_at { get; set; }
    }
}