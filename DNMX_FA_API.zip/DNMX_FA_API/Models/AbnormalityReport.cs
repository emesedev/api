using System;

namespace DNMX_FA_API.Models
{
    public class AbnormalityReport
    {
        public int id_abnormality_report { get; set; }
        public int id_annual_plan { get; set; }
        public int priority { get; set; }
        public DateTime date { get; set; }
        public int id_area { get; set; }
        public int id_category_equipment { get; set; }
        public int id_equipment { get; set; }
        public string finding { get; set; }
        public string immediate_action { get; set; }
        public string final_action { get; set; }
        public int responsible { get; set; }
        public DateTime commitment_date { get; set; }
        public DateTime closing_date { get; set; }
        public string comments { get; set; }
        public string type_failure { get; set; }
        public int type_abnormality { get; set; }
        public int status { get; set; }
    }
}