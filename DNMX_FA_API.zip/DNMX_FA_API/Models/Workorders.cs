using System;

namespace DNMX_FA_API.Models
{
    public class Workorders
    {
        public int id_work_order { get; set; }
        public int id_maintenance { get; set; }
        public string system { get; set; }
        public string description { get; set; }
        public int type { get; set; }
        public int category_result { get; set; }
        public string min { get; set; }
        public string max { get; set; }
    }
}