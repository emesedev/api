using System;

namespace DNMX_FA_API.Models
{
    public class Tools
    {
        public int id_tools { get; set; }
        public int id_maintenance { get; set; }
        public string tools { get; set; }
    }
}