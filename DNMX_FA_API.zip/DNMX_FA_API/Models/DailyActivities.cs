using System;

namespace DNMX_FA_API.Models
{
    public class DailyActivities
    {
        public int id_daily_activities { get; set; }
        public int id_user { get; set; }
        public DateTime date { get; set; }
        public int shift { get; set; }
        public TimeSpan start_time { get; set; }
        public TimeSpan end_time { get; set; }
        public string activity { get; set; }
        public int id_area { get; set; }
        public int id_equipment { get; set; }
        public int classEquipment { get; set; }
        public int id_area_fa { get; set; }
        public int id_category_equipment { get; set; }
        public string comment { get; set; }
        public int minutes { get; set; }
        public float hours { get; set; }
        public int status { get; set; }
    }
}