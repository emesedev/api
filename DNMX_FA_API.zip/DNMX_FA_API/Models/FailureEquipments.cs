using System;

namespace DNMX_FA_API.Models
{
    public class FailureEquipments
    {
        public int id_failure_equipments { get; set; }
        public int id_equipment { get; set; }
        public int id_abnormality_report { get; set; }
        public DateTime date { get; set; }
        public int status { get; set; }
    }
}