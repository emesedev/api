using System;

namespace DNMX_FA_API.Models
{
    public class Materials
    {
        public int id_materials { get; set; }
        public int id_maintenance { get; set; }
        public string materials { get; set; }
    }
}