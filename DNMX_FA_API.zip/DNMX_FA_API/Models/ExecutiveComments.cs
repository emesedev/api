using System;

namespace DNMX_FA_API.Models
{
    public class ExecutiveComments
    {
        public int id_executive_comment { get; set; }
        public DateTime date { get; set; }
        public string comment1 { get; set; }
        public string comment2 { get; set; }
        public string comment3 { get; set; }
        public string comment4 { get; set; }
        public string comment5 { get; set; }
        public string comment6 { get; set; }
        public string comment7 { get; set; }
        public string comment8 { get; set; }
    }
}