using System;

namespace DNMX_FA_API.Models
{
    public class Areasfa
    {
        public int id_area_fa { get; set; }
        public string name { get; set; }
    }
}