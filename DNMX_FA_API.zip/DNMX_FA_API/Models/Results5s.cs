using System;

namespace DNMX_FA_API.Models
{
    public class Results5s
    {
        public int id_result_5s { get; set; }
        public int id_evaluation_5s { get; set; }
        public int value { get; set; }
        public string comment { get; set; }
        public DateTime date { get; set; }
        public int approver { get; set; }
        public int status { get; set; }
    }
}