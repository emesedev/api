using System;

namespace DNMX_FA_API.Models
{
    public class Epp
    {
        public int id_epp { get; set; }
        public int id_maintenance { get; set; }
        public string epp { get; set; }
    }
}