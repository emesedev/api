using System;

namespace DNMX_FA_API.Models
{
    public class MaintenanceEquipments
    {
        public int id_maintenance_equip { get; set; }
        public int id_maintenance { get; set; }
        public int id_equipment { get; set; }
    }
}