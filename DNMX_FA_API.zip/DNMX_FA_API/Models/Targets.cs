using System;

namespace DNMX_FA_API.Models
{
    public class Targets
    {
        public int id_target { get; set; }
        public string name { get; set; }
        public int value { get; set; }
        public DateTime date { get; set; }
    }
}