using System;

namespace DNMX_FA_API.Models
{
    public class AnnualPlan
    {
        public int id_annual_plan { get; set; }
        public int id_work_order { get; set; }
        public int id_equipment { get; set; }
        public int responsible { get; set; }
        public DateTime planned_date { get; set; }
        public DateTime real_date { get; set; }
        public TimeSpan start_time { get; set; }
        public TimeSpan end_time { get; set; }
        public int approver { get; set; }
        public int status { get; set; }
    }
}