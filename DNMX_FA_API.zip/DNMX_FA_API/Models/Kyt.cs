using System;

namespace DNMX_FA_API.Models
{
    public class Kyt
    {
        public int id_kyt { get; set; }
        public int id_user { get; set; }
        public DateTime date { get; set; }
        public int value { get; set; }
    }
}