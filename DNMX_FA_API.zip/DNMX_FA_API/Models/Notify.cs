using System;

namespace DNMX_FA_API.Models
{
    public class Notify
    {
        public int id_notify { get; set; }
        public string comment { get; set; }
        public int id_user { get; set; }
        public DateTime created_date { get; set; }
        public DateTime seen_at { get; set; }
        public int type_activity { get; set; }
        public int id_activity { get; set; }
        public int status { get; set; }
    }
}