using System;

namespace DNMX_FA_API.Models
{
    public class Users
    {
        public int id_user { get; set; }
        public string name { get; set; }
        public string father_lastname { get; set; }
        public string mother_lastname { get; set; }
        public string password { get; set; }
        public int role { get; set; }
        public string position { get; set; }
        public string id_area_fac { get; set; }
        public int id_department { get; set; }
        public string email { get; set; }
        public int id_plant { get; set; }
        public int status { get; set; }
    }
}