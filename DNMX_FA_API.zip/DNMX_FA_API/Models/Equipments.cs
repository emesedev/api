using System;

namespace DNMX_FA_API.Models
{
    public class Equipments
    {
        public int id_equipment { get; set; }
        public string name { get; set; }
        public string location { get; set; }
        public string fa_number { get; set; }
        public int classEquipment { get; set; }
        public int id_area_fa { get; set; }
        public int frequency { get; set; }
        public int responsible { get; set; }
        public int id_plant { get; set; }
        public int status { get; set; }
    }
}