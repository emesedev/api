using Microsoft.EntityFrameworkCore;
using DNMX_FA_API.Models;

namespace DNMX_FA_API.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Users> Users { get; set; }
        public DbSet<Areasfa> Areasfa { get; set; }
        public DbSet<Equipments> Equipments { get; set; }
        public DbSet<Maintenance> Maintenance { get; set; }
        public DbSet<Epp> Epp { get; set; }
        public DbSet<Workorders> Workorders { get; set; }
        public DbSet<Tools> Tools { get; set; }
        public DbSet<MaintenanceEquipments> Maintenance_equipments { get; set; }
        public DbSet<Materials> Materials { get; set; }
        public DbSet<MaintenanceResult> Maintenance_result { get; set; }
        public DbSet<AnnualPlan> Annual_plan { get; set; }
        public DbSet<Areas> Areas { get; set; }
        public DbSet<CategoryEquipment> Category_equipment { get; set; }
        public DbSet<DailyActivities> Daily_activities { get; set; }
        public DbSet<AbnormalityReport> Abnormality_report { get; set; }
        public DbSet<FailureEquipments> Failure_equipments { get; set; }
        public DbSet<Targets> Targets { get; set; }
        public DbSet<ExecutiveComments> Executive_comments { get; set; }
        public DbSet<GasConsumption> Gas_consumption { get; set; }
        public DbSet<WaterConsumption> Water_consumption { get; set; }
        public DbSet<Kyt> Kyt { get; set; }
        public DbSet<Notify> Notify { get; set; }
        public DbSet<Evaluation5s> Evaluation_5s { get; set; }
        public DbSet<Checklist5s> Checklist_5s { get; set; }
        public DbSet<Results5s> Results_5s { get; set; }
    }
}